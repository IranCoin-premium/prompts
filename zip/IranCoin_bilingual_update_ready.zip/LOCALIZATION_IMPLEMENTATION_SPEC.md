# IranCoin — Bilingual Localization Implementation Spec

This package is an implementation-ready localization specification for the existing IranCoin project prompt set.

## Locale contract

- Persian: `fa` / `fa-IR`, direction `rtl`
- English: `en` / `en-US`, direction `ltr`
- Visible compact switch labels: `FA` and `EN`
- `IN` must not be used as the English locale label.

## Header control

Use two touching/nearly-touching circular controls in the existing header/navigation:

`[ 🇮🇷 FA ][ 🇬🇧 EN ]`

The exact existing project design tokens must be reused. The control must not introduce a new color palette or redesign the header.

## Architecture

1. One shared component for both directions.
2. One localization resource namespace per feature.
3. CSS logical properties rather than duplicated LTR/RTL styles.
4. Runtime `dir` switching on the application root/document.
5. Bidi isolation for mixed-direction financial and technical values.
6. Locale-aware Intl formatting for dates, times, numbers, currencies and plurals.
7. Persist explicit language preference.

## Translation policy

Persian must read like native professional fintech copy rather than machine-translated English. Established technical acronyms, exchange names, product codes and instrument symbols remain unchanged where translation would create ambiguity.

## Visual integrity acceptance gate

A bilingual build is accepted only when switching `FA ↔ EN` preserves the original visual system and does not cause clipping, overlap, layout drift, navigation breakage, or corrupted mixed-direction text.
