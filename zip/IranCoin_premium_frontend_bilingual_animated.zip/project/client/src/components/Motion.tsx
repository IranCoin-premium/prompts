/*
 * Shared motion-graphic primitives. Centralizing these keeps animation timing and easing
 * consistent across pages instead of hand-rolled variants scattered per component.
 */
import { motion, useScroll, useSpring, type Variants } from "framer-motion";
import type { ReactNode } from "react";

export const EASE = [0.23, 1, 0.32, 1] as const;

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 28 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: EASE } },
};

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 0.8, ease: EASE } },
};

export const staggerParent: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};

export function Reveal({
  children,
  className,
  delay = 0,
  variants = fadeUp,
  as: Component = motion.div,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  variants?: Variants;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  as?: any;
  onClick?: () => void;
}) {
  const Comp = Component;
  return (
    <Comp
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-80px" }}
      variants={variants}
      transition={{ delay }}
      onClick={onClick}
    >
      {children}
    </Comp>
  );
}

export function Stagger({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <motion.div className={className} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-60px" }} variants={staggerParent}>
      {children}
    </motion.div>
  );
}

export function StaggerItem({
  children,
  className,
  variants = fadeUp,
  as: Component = motion.div,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  variants?: Variants;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  as?: any;
  onClick?: () => void;
}) {
  const Comp = Component;
  return (
    <Comp className={className} variants={variants} onClick={onClick}>
      {children}
    </Comp>
  );
}

/** Ambient full-viewport drifting gradient orbs — the "motion graphic" atmosphere layer. */
export function AmbientField() {
  return (
    <div className="ambient-field" aria-hidden="true">
      <span className="ambient-orb ambient-orb--one" />
      <span className="ambient-orb ambient-orb--two" />
      <span className="ambient-orb ambient-orb--three" />
    </div>
  );
}

/** Thin copper progress bar tracking scroll position, pinned to the top of the viewport. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 24, mass: 0.2 });
  return <motion.div className="scroll-progress" style={{ scaleX }} />;
}

export const pageTransition = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.5, ease: EASE } },
  exit: { opacity: 0, y: -10, transition: { duration: 0.3, ease: EASE } },
};

export { motion };
