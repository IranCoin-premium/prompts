/*
 * Style direction: «سکوتِ کوانت» — an obsidian editorial shell with copper details, a narrow evidence rail,
 * and calm, precise interactions. This file owns the navigation rhythm, brand language, language switch,
 * and the ambient motion layer shared by every page.
 */
import { Link, useLocation } from "wouter";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AnimatePresence, motion } from "framer-motion";
import { useLanguage } from "@/lib/i18n";
import { AmbientField, ScrollProgress } from "@/components/Motion";

export function BrandMark({ small = false }: { small?: boolean }) {
  return (
    <motion.div
      className={`brand-lockup ${small ? "brand-lockup--small" : ""}`}
      whileHover="hover"
      initial="rest"
      animate="rest"
    >
      <span className="brand-mark brand-mark--bars" aria-hidden="true">
        <motion.i variants={{ rest: { scaleY: 1 }, hover: { scaleY: 1.35 } }} transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }} style={{ transformOrigin: "bottom" }} />
        <motion.i variants={{ rest: { scaleY: 1 }, hover: { scaleY: 1.55 } }} transition={{ duration: 0.25, delay: 0.03, ease: [0.23, 1, 0.32, 1] }} style={{ transformOrigin: "bottom" }} />
        <motion.i variants={{ rest: { scaleY: 1 }, hover: { scaleY: 1.7 } }} transition={{ duration: 0.25, delay: 0.06, ease: [0.23, 1, 0.32, 1] }} style={{ transformOrigin: "bottom" }} />
      </span>
      <span className="brand-wordmark">IRANCOIN</span>
    </motion.div>
  );
}

function LanguageToggle() {
  const { lang, toggleLang } = useLanguage();
  return (
    <button
      className="lang-toggle"
      onClick={toggleLang}
      aria-label="Switch language / تغییر زبان"
      title="EN / فارسی"
    >
      <motion.span
        className="lang-toggle__thumb"
        animate={{ x: lang === "en" ? 0 : "100%" }}
        transition={{ type: "spring", stiffness: 420, damping: 34 }}
      />
      <span className={`lang-toggle__option ${lang === "en" ? "is-active" : ""}`}>EN</span>
      <span className={`lang-toggle__option ${lang === "fa" ? "is-active" : ""}`}>فا</span>
    </button>
  );
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { t } = useLanguage();

  const navItems = [
    { href: "/research", label: t("nav.research") },
    { href: "/dashboard", label: t("nav.workspace") },
    { href: "/pricing", label: t("nav.access") },
  ];

  const handleSoon = () => {
    toast(t("toast.signInDisabled"), { description: t("toast.signInDisabledDesc") });
  };

  return (
    <div className="site-frame">
      <ScrollProgress />
      <AmbientField />
      <motion.header
        className="site-header"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      >
        <div className="site-header__inner">
          <Link href="/" onClick={() => setMenuOpen(false)} aria-label="IranCoin Premium home">
            <BrandMark />
          </Link>
          <nav className="desktop-nav" aria-label="Primary navigation">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}>
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="header-actions">
            <span className="header-status"><i /> {t("nav.systems")}</span>
            <LanguageToggle />
            <motion.button className="button button--quiet button--compact" onClick={handleSoon} whileTap={{ scale: 0.95 }}>
              {t("nav.signIn")} <ArrowUpRight size={15} />
            </motion.button>
            <button className="menu-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" aria-expanded={menuOpen}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && (
            <motion.nav
              className="mobile-nav"
              aria-label="Mobile navigation"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1, display: "flex" }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
              style={{ overflow: "hidden" }}
            >
              {navItems.map((item, index) => (
                <motion.div
                  key={item.href}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + index * 0.04 }}
                >
                  <Link href={item.href} onClick={() => setMenuOpen(false)} className={location === item.href ? "is-active" : ""}>
                    {item.label}
                  </Link>
                </motion.div>
              ))}
              <LanguageToggle />
              <button className="button button--quiet" onClick={handleSoon}>{t("nav.signIn")} <ArrowUpRight size={15} /></button>
            </motion.nav>
          )}
        </AnimatePresence>
      </motion.header>
      <main>{children}</main>
      <footer className="site-footer">
        <div className="site-footer__grid">
          <div>
            <BrandMark small />
            <p className="footer-copy">{t("footer.tagline")}</p>
          </div>
          <div className="footer-links">
            <span className="eyebrow">{t("footer.explore")}</span>
            <Link href="/research">{t("footer.research")}</Link>
            <Link href="/dashboard">{t("footer.workspace")}</Link>
            <Link href="/pricing">{t("footer.pricing")}</Link>
          </div>
          <div className="footer-links">
            <span className="eyebrow">{t("footer.boundary")}</span>
            <span>{t("footer.notAdvice")}</span>
            <span>{t("footer.illustrative")}</span>
            <span>{t("footer.version")}</span>
          </div>
        </div>
        <div className="footer-bottom"><span>{t("footer.copyright")}</span><span>{t("footer.builtFor")}</span></div>
      </footer>
    </div>
  );
}

export function EvidenceRail({ label, value }: { label?: string; value?: string }) {
  const { t } = useLanguage();
  return (
    <motion.div className="evidence-rail" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}>
      <span className="evidence-rail__line"><i /><i /><i /></span>
      <div><span className="eyebrow">{label ?? t("home.evidenceLabel")}</span><span className="evidence-rail__value">{value ?? t("home.evidenceValue")}</span></div>
    </motion.div>
  );
}

export function SectionLabel({ index, children }: { index: string; children: React.ReactNode }) {
  return (
    <motion.div className="section-label" initial={{ opacity: 0, y: 8 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
      <span>{index}</span><span>{children}</span>
    </motion.div>
  );
}
