/*
 * Style direction: «سکوتِ کوانت» — dark editorial finance, asymmetric layouts, copper signal accents,
 * calm motion, and explicit product boundaries. Keep the shell quiet so evidence and actions lead.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./lib/i18n";
import { pageTransition } from "./components/Motion";
import Home from "./pages/Home";
import Research from "./pages/Research";
import Dashboard from "./pages/Dashboard";
import Pricing from "./pages/Pricing";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

function AnimatedPage({ children }: { children: React.ReactNode }) {
  return (
    <motion.div initial="initial" animate="animate" exit="exit" variants={pageTransition}>
      {children}
    </motion.div>
  );
}

function Router() {
  const [location] = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <Switch key={location} location={location}>
        <Route path="/" component={() => <AnimatedPage><Home /></AnimatedPage>} />
        <Route path="/research" component={() => <AnimatedPage><Research /></AnimatedPage>} />
        <Route path="/dashboard" component={() => <AnimatedPage><Dashboard /></AnimatedPage>} />
        <Route path="/pricing" component={() => <AnimatedPage><Pricing /></AnimatedPage>} />
        <Route path="/profile" component={() => <AnimatedPage><Profile /></AnimatedPage>} />
        <Route path="/404" component={() => <AnimatedPage><NotFound /></AnimatedPage>} />
        <Route component={() => <AnimatedPage><NotFound /></AnimatedPage>} />
      </Switch>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <LanguageProvider>
        <ThemeProvider defaultTheme="dark">
          <TooltipProvider>
            <Toaster position="bottom-left" richColors />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </LanguageProvider>
    </ErrorBoundary>
  );
}
