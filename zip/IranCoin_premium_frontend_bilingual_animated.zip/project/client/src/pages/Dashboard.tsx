/*
 * Style direction: «سکوتِ کوانت» — a persistent analyst desk with soft surfaces, strict status hierarchy,
 * copper for attention, sage for healthy state, and no live-trading promises in the demo layer.
 */
import { Activity, ArrowUpRight, Bell, CircleHelp, Eye, LockKeyhole, MoreHorizontal, Plus, Settings2, ShieldCheck, SlidersHorizontal, WalletCards } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { SectionLabel, SiteShell } from "@/components/SiteShell";
import { motion, Reveal, Stagger, StaggerItem } from "@/components/Motion";
import { useLanguage } from "@/lib/i18n";

const signalRows = [
  { pair: "BTC / USD", stanceKey: "dash.constructive", score: "78", change: "+2.41%", tone: "positive", time: "08:39" },
  { pair: "ETH / USD", stanceKey: "dash.watching", score: "54", change: "+1.08%", tone: "neutral", time: "08:34" },
  { pair: "SOL / USD", stanceKey: "dash.cautious", score: "32", change: "−0.64%", tone: "negative", time: "08:27" },
];

function Chart() {
  const pathD = "M0 180 C38 169, 48 142, 80 152 S124 175, 154 137 S205 102, 240 121 S277 130, 305 93 S341 105, 371 88 S414 98, 451 69 S487 84, 518 58 S557 80, 586 48 S630 52, 700 22";
  return (
    <div className="line-chart">
      <svg viewBox="0 0 700 210" preserveAspectRatio="none" role="img" aria-label="Illustrative portfolio posture chart">
        <defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#C8754A" stopOpacity=".22" /><stop offset="100%" stopColor="#C8754A" stopOpacity="0" /></linearGradient></defs>
        <path className="chart-grid" d="M0 42H700 M0 95H700 M0 148H700 M0 200H700" />
        <path className="chart-area" d={`${pathD} V210 H0Z`} />
        <motion.path className="chart-line" d={pathD} initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.6, ease: [0.23, 1, 0.32, 1] }} />
        <motion.circle cx="700" cy="22" r="4" className="chart-dot" initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1.4, duration: 0.4 }} />
      </svg>
      <div className="chart-labels"><span>14 Aug</span><span>18 Aug</span><span>22 Aug</span><span>28 Aug</span></div>
    </div>
  );
}

export default function Dashboard() {
  const { t } = useLanguage();
  const [selected, setSelected] = useState(t("dash.days30"));
  const notify = () => toast(t("toast.liveDisabled"), { description: t("toast.liveDisabledDesc") });
  const ranges = [t("dash.days7"), t("dash.days30"), t("dash.days90")];

  return (
    <SiteShell>
      <div className="app-shell">
        <motion.aside className="app-sidebar" initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}>
          <div className="app-sidebar__brand"><Link href="/"><span className="sidebar-symbol">I</span><span>IRANCOIN</span></Link></div>
          <div className="sidebar-section">
            <span className="sidebar-caption">{t("nav.workspace")}</span>
            <Link href="/dashboard" className="is-active"><Activity size={17} /> {t("dash.overview")}</Link>
            <button onClick={notify}><WalletCards size={17} /> {t("dash.positions")} <span className="sidebar-soon">{t("dash.soon")}</span></button>
            <button onClick={notify}><Bell size={17} /> {t("dash.alerts")} <span className="sidebar-badge">3</span></button>
          </div>
          <div className="sidebar-section">
            <span className="sidebar-caption">Intelligence</span>
            <Link href="/research"><Eye size={17} /> {t("dash.researchJournal")}</Link>
            <button onClick={notify}><SlidersHorizontal size={17} /> {t("dash.automations")} <span className="sidebar-soon">{t("dash.soon")}</span></button>
          </div>
          <div className="sidebar-section sidebar-section--bottom">
            <button onClick={notify}><Settings2 size={17} /> {t("dash.settings")}</button>
            <button onClick={notify}><CircleHelp size={17} /> {t("dash.helpCenter")}</button>
          </div>
          <Link href="/profile" className="sidebar-profile"><div className="avatar">AR</div><div><strong>{t("dash.analystPreview")}</strong><span>{t("dash.observerAccess")}</span></div><MoreHorizontal size={17} /></Link>
        </motion.aside>
        <div className="app-main">
          <motion.header className="app-topbar" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div><span className="eyebrow">{t("dash.workspaceOverview")}</span><h1>{t("dash.goodMorning")}</h1></div>
            <div className="app-topbar__actions">
              <button className="icon-button" onClick={notify} aria-label="Notifications"><Bell size={18} /><i /></button>
              <motion.button className="button button--copper button--compact" onClick={notify} whileTap={{ scale: 0.95 }}><Plus size={16} /> {t("dash.connectVenue")}</motion.button>
            </div>
          </motion.header>
          <Reveal className="demo-notice" delay={0.1}>
            <ShieldCheck size={16} /><span><strong>{t("dash.demoTitle")}</strong> {t("dash.demoBody")}</span>
            <button onClick={notify}>{t("dash.learnBoundaries")} <ArrowUpRight size={14} /></button>
          </Reveal>
          <Stagger className="workspace-grid">
            <StaggerItem className="metric-card metric-card--hero">
              <div className="metric-card__top"><span>{t("dash.portfolioPosture")}</span><span className="status-pill status-pill--sage"><i /> {t("dash.measured")}</span></div>
              <strong>+12.84%</strong>
              <div className="metric-card__sub"><span>{t("dash.illustrativePeriod")}</span><span className="is-positive"><ArrowUpRight size={13} /> 2.16% {t("dash.today")}</span></div>
              <Chart />
            </StaggerItem>
            <StaggerItem className="metric-card">
              <div className="metric-card__top"><span>{t("dash.availableBalance")}</span><WalletCards size={18} /></div>
              <strong>$48,240<span className="metric-unit">.00</span></strong>
              <div className="metric-card__sub"><span>{t("dash.usdEquivalent")}</span><span>{t("dash.readOnly")}</span></div>
              <div className="balance-bars"><motion.i initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }} style={{ transformOrigin: "left", width: "62%" }} /><motion.i initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }} style={{ transformOrigin: "left", width: "23%" }} /><motion.i initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.2 }} style={{ transformOrigin: "left", width: "15%" }} /></div>
              <div className="balance-legend"><span><i className="legend-copper" /> {t("dash.spot")}</span><span><i className="legend-sage" /> {t("dash.cash")}</span></div>
            </StaggerItem>
            <StaggerItem className="metric-card metric-card--connection">
              <div className="metric-card__top"><span>{t("dash.connectionHealth")}</span><LockKeyhole size={18} /></div>
              <div className="connection-state">
                <div className="connection-orbit"><motion.i animate={{ rotate: 360 }} transition={{ duration: 6, repeat: Infinity, ease: "linear" }} /><span>OK</span></div>
                <div><strong>{t("dash.vaultProtected")}</strong><p>{t("dash.lastChecked")}</p></div>
              </div>
              <button className="card-link" onClick={notify}>{t("dash.viewPermission")} <ArrowUpRight size={14} /></button>
            </StaggerItem>
          </Stagger>
          <section className="signals-section">
            <div className="signals-header">
              <div><SectionLabel index="01">{t("dash.signalWatchlist")}</SectionLabel><h2>{t("dash.contextNotCommands")}</h2></div>
              <div className="signals-controls">
                <div className="segmented-control">{ranges.map((range) => <button key={range} onClick={() => setSelected(range)} className={selected === range ? "is-active" : ""}>{range}</button>)}</div>
                <button className="icon-button icon-button--bordered" onClick={notify} aria-label="More filters"><SlidersHorizontal size={16} /></button>
              </div>
            </div>
            <div className="signals-table">
              <div className="signals-table__head"><span>{t("dash.instrument")}</span><span>{t("dash.currentRead")}</span><span>{t("dash.contextScore")}</span><span>{t("dash.move24h")}</span><span>{t("dash.updated")}</span><span /></div>
              <Stagger>
                {signalRows.map((row) => (
                  <StaggerItem
                    key={row.pair}
                    as={motion.button}
                    className="signal-row"
                    onClick={notify}
                    variants={{ hidden: { opacity: 0, x: -14 }, show: { opacity: 1, x: 0, transition: { duration: 0.4 } } }}
                  >
                    <span className="signal-instrument"><span className={`asset-dot asset-dot--${row.tone}`}>{row.pair.slice(0, 1)}</span><strong>{row.pair}</strong></span>
                    <span className={`signal-stance signal-stance--${row.tone}`}>{t(row.stanceKey)}</span>
                    <span className="score-meter"><i style={{ width: `${row.score}%` }} /><b>{row.score}</b></span>
                    <span className={row.tone === "negative" ? "is-negative" : "is-positive"}>{row.change}</span>
                    <span className="mono-label">{row.time} UTC</span>
                    <ArrowUpRight size={16} className="signal-arrow" />
                  </StaggerItem>
                ))}
              </Stagger>
            </div>
          </section>
          <Reveal as={motion.section} className="workspace-foot">
            <div><SectionLabel index="02">{t("dash.nextLayer")}</SectionLabel><h2>{t("dash.bringOwnEvidence1")}<br /><em>{t("dash.bringOwnEvidenceEm")}</em></h2><p>{t("dash.bringOwnBody")}</p></div>
            <button className="button button--outline" onClick={notify}>{t("dash.reviewConnection")} <ArrowUpRight size={16} /></button>
          </Reveal>
        </div>
      </div>
    </SiteShell>
  );
}
