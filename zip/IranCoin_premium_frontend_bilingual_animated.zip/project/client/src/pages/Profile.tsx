/*
 * Style direction: «سکوتِ کوانت» — profile management is a quiet control room, with explicit state,
 * precise fields, and no false implication that demo changes are persisted to a backend.
 */
import { Bell, Check, ChevronRight, Globe2, KeyRound, LoaderCircle, LockKeyhole, LogOut, Mail, Save, ShieldCheck, UserRound } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { AnimatePresence } from "framer-motion";
import { SiteShell } from "@/components/SiteShell";
import { motion, Reveal } from "@/components/Motion";
import { useLanguage, type Lang } from "@/lib/i18n";

function DashboardSidebar({ t }: { t: (key: string) => string }) {
  return (
    <aside className="app-sidebar">
      <div className="app-sidebar__brand"><Link href="/"><span className="sidebar-symbol">I</span><span>IRANCOIN</span></Link></div>
      <div className="sidebar-section">
        <span className="sidebar-caption">{t("nav.workspace")}</span>
        <Link href="/dashboard"><span>⌁</span> {t("dash.overview")}</Link>
        <button><span>▣</span> {t("dash.positions")} <span className="sidebar-soon">{t("dash.soon")}</span></button>
        <button><Bell size={17} /> {t("dash.alerts")} <span className="sidebar-badge">3</span></button>
      </div>
      <div className="sidebar-section">
        <span className="sidebar-caption">Intelligence</span>
        <Link href="/research"><span>◌</span> {t("dash.researchJournal")}</Link>
        <button><span>≡</span> {t("dash.automations")} <span className="sidebar-soon">{t("dash.soon")}</span></button>
      </div>
      <div className="sidebar-section sidebar-section--bottom">
        <Link href="/profile" className="is-active"><UserRound size={17} /> {t("profile.tabAccount")}</Link>
        <button><span>?</span> {t("dash.helpCenter")}</button>
      </div>
      <Link href="/profile" className="sidebar-profile"><div className="avatar">AR</div><div><strong>{t("dash.analystPreview")}</strong><span>{t("dash.observerAccess").split("·")[0]}</span></div></Link>
    </aside>
  );
}

function Toggle({ label, description, checked, onChange }: { label: string; description: string; checked: boolean; onChange: (value: boolean) => void }) {
  return <label className="profile-toggle"><span><strong>{label}</strong><small>{description}</small></span><input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} /><i className="toggle-track"><b /></i></label>;
}

export default function Profile() {
  const { t, lang, setLang } = useLanguage();
  const [activeTab, setActiveTab] = useState("account");
  const [name, setName] = useState("Arman Rahimi");
  const [email, setEmail] = useState("arman@iran-coin.example");
  const [role, setRole] = useState(t("profile.roleAnalyst"));
  const [weeklyNote, setWeeklyNote] = useState(true);
  const [signalAlerts, setSignalAlerts] = useState(true);
  const [productNotes, setProductNotes] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const save = async () => {
    if (isSaving) return;
    const normalizedName = name.trim();
    const normalizedEmail = email.trim();
    if (normalizedName.length < 3) {
      toast.error(t("toast.saveFailedName"), { description: t("toast.saveFailedNameDesc") });
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(normalizedEmail)) {
      toast.error(t("toast.saveFailedEmail"), { description: t("toast.saveFailedEmailDesc") });
      return;
    }
    setIsSaving(true);
    try {
      await new Promise((resolve) => window.setTimeout(resolve, 900));
      toast.success(t("toast.saveSuccess"), { description: t("toast.saveSuccessDesc") });
    } catch {
      toast.error(t("toast.saveError"), { description: t("toast.saveErrorDesc") });
    } finally {
      setIsSaving(false);
    }
  };
  const soon = () => toast(t("toast.featureDisabled"), { description: t("toast.featureDisabledDesc") });

  const tabs = [
    { id: "account", label: t("profile.tabAccount"), icon: UserRound },
    { id: "notifications", label: t("profile.tabNotifications"), icon: Bell },
    { id: "security", label: t("profile.tabSecurity"), icon: LockKeyhole },
    { id: "preferences", label: t("profile.tabPreferences"), icon: Globe2 },
  ];

  return (
    <SiteShell>
      <div className="app-shell">
        <DashboardSidebar t={t} />
        <div className="app-main profile-main">
          <motion.header className="app-topbar profile-topbar" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div><span className="eyebrow">{t("profile.workspaceProfile")}</span><h1>{t("profile.accountSettings")}</h1></div>
            <div className="profile-topbar__status"><ShieldCheck size={15} /> {t("profile.protectedPreview")}</div>
          </motion.header>
          <Reveal className="profile-intro" delay={0.05}>
            <div className="profile-avatar-large">AR</div>
            <div><h2>Arman Rahimi</h2><p>{t("profile.independentAnalyst")}</p><span className="profile-last-seen">{t("profile.lastReview")}</span></div>
            <button className="button button--outline button--compact" onClick={soon}><LogOut size={14} /> {t("profile.signOut")}</button>
          </Reveal>
          <div className="profile-layout">
            <motion.nav className="profile-tabs" aria-label="Profile sections" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1, duration: 0.5 }}>
              {tabs.map(({ id, label, icon: Icon }) => (
                <button key={id} className={activeTab === id ? "is-active" : ""} onClick={() => setActiveTab(id)}>
                  <Icon size={16} />{label}<ChevronRight size={14} />
                </button>
              ))}
            </motion.nav>
            <motion.section className="profile-panel" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15, duration: 0.5 }}>
              <AnimatePresence mode="wait">
                {activeTab === "account" && (
                  <motion.div key="account" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
                    <div className="profile-panel__heading"><div><span className="eyebrow">{t("profile.accountIdentity")}</span><h2>{t("profile.personalDetails")}</h2></div><span className="profile-state"><i /> {t("profile.editable")}</span></div>
                    <p className="profile-panel__lede">{t("profile.accountLede")}</p>
                    <div className="profile-form">
                      <label><span>{t("profile.fullName")}</span><input value={name} onChange={(event) => setName(event.target.value)} /></label>
                      <label><span>{t("profile.emailAddress")}</span><div className="input-with-icon"><Mail size={15} /><input value={email} onChange={(event) => setEmail(event.target.value)} type="email" /></div></label>
                      <label><span>{t("profile.workspaceRole")}</span><select value={role} onChange={(event) => setRole(event.target.value)}><option>{t("profile.roleAnalyst")}</option><option>{t("profile.roleLead")}</option><option>{t("profile.roleObserver")}</option></select></label>
                      <label><span>{t("profile.timeZone")}</span><select defaultValue="Europe/Tehran"><option value="Europe/Tehran">Tehran · UTC+03:30</option><option value="UTC">UTC</option><option value="America/New_York">New York · UTC−04:00</option></select></label>
                    </div>
                    <div className="profile-panel__footer">
                      <span><Check size={14} /> {t("profile.changesLocal")}</span>
                      <motion.button className="button button--copper" onClick={() => void save()} disabled={isSaving} aria-busy={isSaving} whileTap={{ scale: 0.97 }}>
                        <span className={isSaving ? "button-spinner" : ""}>{isSaving ? <LoaderCircle size={15} /> : <Save size={15} />}</span>{isSaving ? t("profile.saving") : t("profile.saveChanges")}
                      </motion.button>
                    </div>
                  </motion.div>
                )}
                {activeTab === "notifications" && (
                  <motion.div key="notifications" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
                    <div className="profile-panel__heading"><div><span className="eyebrow">{t("profile.signalDesk")}</span><h2>{t("profile.notificationRhythm")}</h2></div><span className="profile-state"><i /> {t("profile.preference")}</span></div>
                    <p className="profile-panel__lede">{t("profile.notifLede")}</p>
                    <div className="toggle-list">
                      <Toggle label={t("profile.weeklyNote")} description={t("profile.weeklyNoteDesc")} checked={weeklyNote} onChange={setWeeklyNote} />
                      <Toggle label={t("profile.signalAlerts")} description={t("profile.signalAlertsDesc")} checked={signalAlerts} onChange={setSignalAlerts} />
                      <Toggle label={t("profile.productNotes")} description={t("profile.productNotesDesc")} checked={productNotes} onChange={setProductNotes} />
                    </div>
                    <div className="profile-panel__footer">
                      <span><Bell size={14} /> {Number(weeklyNote) + Number(signalAlerts) + Number(productNotes)} {t("profile.preferencesActive")}</span>
                      <motion.button className="button button--copper" onClick={() => void save()} disabled={isSaving} aria-busy={isSaving} whileTap={{ scale: 0.97 }}>
                        <span className={isSaving ? "button-spinner" : ""}>{isSaving ? <LoaderCircle size={15} /> : <Save size={15} />}</span>{isSaving ? t("profile.saving") : t("profile.savePreferences")}
                      </motion.button>
                    </div>
                  </motion.div>
                )}
                {activeTab === "security" && (
                  <motion.div key="security" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
                    <div className="profile-panel__heading"><div><span className="eyebrow">{t("profile.accessControl")}</span><h2>{t("profile.securityPosture")}</h2></div><span className="profile-state profile-state--sage"><i /> {t("profile.protected")}</span></div>
                    <p className="profile-panel__lede">{t("profile.securityLede")}</p>
                    <div className="security-list">
                      <button onClick={soon}><div className="security-icon"><KeyRound size={17} /></div><div><strong>{t("profile.changePassword")}</strong><small>{t("profile.changePasswordDesc")}</small></div><ChevronRight size={17} /></button>
                      <button onClick={soon}><div className="security-icon"><ShieldCheck size={17} /></div><div><strong>{t("profile.twoStep")}</strong><small>{t("profile.twoStepDesc")}</small></div><span className="status-pill status-pill--copper">{t("profile.setup")}</span></button>
                      <button onClick={soon}><div className="security-icon"><LockKeyhole size={17} /></div><div><strong>{t("profile.connectedVenues")}</strong><small>{t("profile.connectedVenuesDesc")}</small></div><ChevronRight size={17} /></button>
                    </div>
                    <div className="profile-boundary-note"><ShieldCheck size={16} /><span><strong>{t("profile.vaultBoundary")}</strong> {t("profile.vaultBoundaryBody")}</span></div>
                  </motion.div>
                )}
                {activeTab === "preferences" && (
                  <motion.div key="preferences" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
                    <div className="profile-panel__heading"><div><span className="eyebrow">{t("profile.workspaceBehavior")}</span><h2>{t("profile.interfacePrefs")}</h2></div><span className="profile-state"><i /> {t("profile.local")}</span></div>
                    <p className="profile-panel__lede">{t("profile.prefsLede")}</p>
                    <div className="preference-rows">
                      <label><span><strong>{t("profile.language")}</strong><small>{t("profile.languageDesc")}</small></span><select value={lang} onChange={(event) => setLang(event.target.value as Lang)}><option value="en">English</option><option value="fa">فارسی</option></select></label>
                      <label><span><strong>{t("profile.numberFormat")}</strong><small>{t("profile.numberFormatDesc")}</small></span><select defaultValue="International"><option>International</option><option>Persian locale</option></select></label>
                      <label><span><strong>{t("profile.reducedMotion")}</strong><small>{t("profile.reducedMotionDesc")}</small></span><input type="checkbox" defaultChecked /></label>
                    </div>
                    <div className="profile-panel__footer">
                      <span><Globe2 size={14} /> {t("profile.prefsApply")}</span>
                      <motion.button className="button button--copper" onClick={() => void save()} disabled={isSaving} aria-busy={isSaving} whileTap={{ scale: 0.97 }}>
                        <span className={isSaving ? "button-spinner" : ""}>{isSaving ? <LoaderCircle size={15} /> : <Save size={15} />}</span>{isSaving ? t("profile.saving") : t("profile.savePreferences")}
                      </motion.button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.section>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
