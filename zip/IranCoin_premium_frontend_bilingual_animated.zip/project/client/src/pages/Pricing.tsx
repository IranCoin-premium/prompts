/*
 * Style direction: «سکوتِ کوانت» — access is framed as a considered product decision, not a countdown.
 * Pricing cards use quiet material contrast, explicit entitlements, and visible platform/jurisdiction boundaries.
 */
import { ArrowUpRight, Check, CircleAlert, LockKeyhole, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { AnimatePresence } from "framer-motion";
import { EvidenceRail, SectionLabel, SiteShell } from "@/components/SiteShell";
import { motion, Reveal, Stagger, StaggerItem } from "@/components/Motion";
import { useLanguage } from "@/lib/i18n";

export default function Pricing() {
  const { t } = useLanguage();
  const terms = [
    { label: t("price.term7"), price: "$18", note: t("price.term7note") },
    { label: t("price.term1m"), price: "$49", note: t("price.term1mNote") },
    { label: t("price.term3m"), price: "$129", note: t("price.term3mNote") },
    { label: t("price.term6m"), price: "$228", note: t("price.term6mNote") },
    { label: t("price.term1y"), price: "$396", note: t("price.term1yNote") },
  ];
  const included = [t("price.inc1"), t("price.inc2"), t("price.inc3"), t("price.inc4"), t("price.inc5")];
  const [selected, setSelected] = useState(terms[2].label);
  const selectedTerm = terms.find((term) => term.label === selected) ?? terms[2];
  const request = () => toast(t("toast.paymentDisabled"), { description: t("toast.paymentDisabledDesc") });

  return (
    <SiteShell>
      <section className="page-intro section-pad page-intro--pricing">
        <div className="container page-intro__grid">
          <Reveal>
            <EvidenceRail label={t("price.accessDesk")} value={t("price.transparent")} />
            <SectionLabel index="01">{t("price.chooseHorizon")}</SectionLabel>
            <h1>{t("price.accessWith1")}<br /><em>{t("price.accessWithEm")}</em></h1>
          </Reveal>
          <Reveal delay={0.15} className="page-intro__aside">
            <p>{t("price.oneService")}</p>
            <div className="page-intro__meta"><span><LockKeyhole size={15} /> {t("price.secureOnboarding")}</span><span><CircleAlert size={15} /> {t("price.availability")}</span></div>
          </Reveal>
        </div>
      </section>
      <section className="pricing-section section-pad">
        <div className="container pricing-layout">
          <Reveal className="pricing-terms">
            <div className="pricing-terms__header"><span className="eyebrow">{t("price.selectTerm")}</span><span className="mono-label">{t("price.usdIllustrative")}</span></div>
            <Stagger>
              {terms.map((term) => (
                <StaggerItem
                  key={term.label}
                  as={motion.button}
                  className={`term-row ${selected === term.label ? "is-active" : ""}`}
                  onClick={() => setSelected(term.label)}
                  variants={{ hidden: { opacity: 0, x: -12 }, show: { opacity: 1, x: 0, transition: { duration: 0.4 } } }}
                >
                  <span className="term-radio"><i /></span>
                  <span className="term-row__name"><strong>{term.label}</strong><small>{term.note}</small></span>
                  <span className="term-row__price">{term.price}<small> / term</small></span>
                  <ArrowUpRight size={17} />
                </StaggerItem>
              ))}
            </Stagger>
            <div className="pricing-terms__note"><ShieldCheck size={16} /><span>{t("price.noTiering")}</span></div>
          </Reveal>
          <Reveal delay={0.2} className="pricing-summary">
            <div className="summary-card">
              <div className="summary-card__top"><span className="eyebrow">{t("price.yourAccess")}</span><span className="status-pill status-pill--copper">{t("price.preview")}</span></div>
              <AnimatePresence mode="wait">
                <motion.div key={selected} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.25 }}>
                  <h2>{selectedTerm.label}</h2>
                  <div className="summary-price">{selectedTerm.price}<span> {t("price.perTerm")}</span></div>
                </motion.div>
              </AnimatePresence>
              <div className="summary-divider" />
              <span className="eyebrow">{t("price.includedEvery")}</span>
              <ul>{included.map((item, i) => <motion.li key={item} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06, duration: 0.4 }}><Check size={15} />{item}</motion.li>)}</ul>
              <motion.button className="button button--copper button--wide" onClick={request} whileTap={{ scale: 0.98 }}>{t("price.continue")} <ArrowUpRight size={16} /></motion.button>
              <p className="summary-footnote">{t("price.footnote")}</p>
            </div>
          </Reveal>
        </div>
      </section>
      <section className="access-boundary section-pad section-dark">
        <div className="container access-boundary__grid">
          <Reveal><SectionLabel index="02">{t("price.readThisFirst")}</SectionLabel><h2>{t("price.accessIsNot1")}<br /><span>{t("price.accessIsNotEm")}</span></h2></Reveal>
          <Reveal delay={0.15}>
            <p>{t("price.accessBody")}</p>
            <div className="boundary-list"><span><i /> {t("price.list1")}</span><span><i /> {t("price.list2")}</span><span><i /> {t("price.list3")}</span></div>
            <Link href="/research" className="text-link">{t("price.readRisk")} <ArrowUpRight size={15} /></Link>
          </Reveal>
        </div>
      </section>
    </SiteShell>
  );
}
