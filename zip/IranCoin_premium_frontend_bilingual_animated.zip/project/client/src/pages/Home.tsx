/*
 * Style direction: «سکوتِ کوانت» — the landing page is an editorial instrument, not a sales funnel.
 * Use asymmetric composition, copper signal accents, evidence rails, and a measured, non-promissory voice.
 */
import { ArrowUpRight, BarChart3, ChevronRight, CircleAlert, Eye, LockKeyhole, Play, ShieldCheck, Sparkles, Waypoints } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { EvidenceRail, SectionLabel, SiteShell } from "@/components/SiteShell";
import { motion, Reveal, Stagger, StaggerItem, fadeUp } from "@/components/Motion";
import { useLanguage } from "@/lib/i18n";

const marketItems = [
  { name: "BTC / USD", price: "$67,420.18", change: "+2.41%", positive: true },
  { name: "ETH / USD", price: "$3,482.06", change: "+1.08%", positive: true },
  { name: "DXY", price: "104.21", change: "−0.18%", positive: false },
  { name: "10Y yield", price: "4.21%", change: "+0.04", positive: false },
];

export default function Home() {
  const { t } = useLanguage();
  const showSoon = () => toast(t("toast.signInDisabled"), { description: t("toast.signInDisabledDesc") });

  const workflow = [
    { number: "01", title: t("home.wf1Title"), body: t("home.wf1Body"), icon: <Eye size={22} /> },
    { number: "02", title: t("home.wf2Title"), body: t("home.wf2Body"), icon: <Sparkles size={22} /> },
    { number: "03", title: t("home.wf3Title"), body: t("home.wf3Body"), icon: <Waypoints size={22} /> },
  ];

  return (
    <SiteShell>
      <section className="hero section-pad">
        <motion.div className="hero__art" aria-hidden="true" initial={{ opacity: 0, scale: 1.06 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.1, ease: [0.23, 1, 0.32, 1] }}>
          <img src="/manus-storage/irancoin-hero-reference_76d916cf.png" alt="" />
          <div className="hero__art-shade" />
          <div className="hero__coordinate coordinate-one">35°41' N / 51°25' E</div>
          <div className="hero__coordinate coordinate-two">FIELD NOTE / 08.42</div>
        </motion.div>
        <div className="hero__content container">
          <motion.div className="hero__eyebrow" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15, duration: 0.6 }}>
            <span className="pulse-dot" /> {t("home.eyebrow")}
          </motion.div>
          <div className="hero__copy">
            <EvidenceRail />
            <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.8, ease: [0.23, 1, 0.32, 1] }}>
              {t("home.heroTitle1")}<br /><em>{t("home.heroTitleEm")}</em> {t("home.heroTitle2")}
            </motion.h1>
            <motion.p className="hero__lede" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.7, ease: [0.23, 1, 0.32, 1] }}>
              {t("home.heroLede")}
            </motion.p>
            <motion.div className="hero__actions" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.42, duration: 0.7, ease: [0.23, 1, 0.32, 1] }}>
              <motion.div whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }}>
                <Link href="/dashboard" className="button button--copper">{t("home.openWorkspace")} <ArrowUpRight size={17} /></Link>
              </motion.div>
              <Link href="/research" className="text-link">{t("home.readMethodology")} <ChevronRight size={15} /></Link>
            </motion.div>
          </div>
          <motion.div className="hero__note" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6, duration: 0.8 }}>
            <span>01</span><p>{t("home.note")}<br />{t("home.note2")}</p>
          </motion.div>
        </div>
      </section>

      <section className="ticker-bar" aria-label="Illustrative market context">
        <div className="ticker-bar__label"><span className="eyebrow">{t("home.marketContext")}</span><span>{t("home.illustrativeDelayed")}</span></div>
        <Stagger className="ticker-bar__items">
          {marketItems.map((item) => (
            <StaggerItem key={item.name} className="ticker-item">
              <span>{item.name}</span><strong>{item.price}</strong><small className={item.positive ? "is-positive" : "is-negative"}>{item.change}</small>
            </StaggerItem>
          ))}
        </Stagger>
      </section>

      <section className="manifesto section-pad">
        <div className="container manifesto__grid">
          <div className="manifesto__aside">
            <SectionLabel index="02">{t("home.manifestoLabel")}</SectionLabel>
            <Reveal as={motion.span} className="manifesto__stamp" delay={0.1}>{t("home.manifestoStamp")}</Reveal>
          </div>
          <div className="manifesto__body">
            <Reveal as={motion.p} className="display-copy">{t("home.manifestoLead1")} <span>{t("home.manifestoLeadEm")}</span> {t("home.manifestoLead2")}</Reveal>
            <Reveal as={motion.div} className="manifesto__details" delay={0.15}>
              <p>{t("home.manifestoBody")}</p>
              <Link href="/research" className="text-link">{t("home.whyMatters")} <ChevronRight size={15} /></Link>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="workflow section-pad section-dark">
        <div className="container">
          <div className="section-heading section-heading--split">
            <div><SectionLabel index="03">{t("home.osLabel")}</SectionLabel><h2>{t("home.osTitle1")}<br /><span>{t("home.osTitleEm")}</span></h2></div>
            <p>{t("home.osLede")}</p>
          </div>
          <Stagger className="workflow__list">
            {workflow.map((item) => (
              <StaggerItem key={item.number} className="workflow-card" variants={{ hidden: { opacity: 0, y: 40 }, show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.23, 1, 0.32, 1] } } }}>
                <motion.article whileHover={{ y: -6 }} transition={{ duration: 0.25 }} style={{ height: "100%" }}>
                  <span className="workflow-card__number">{item.number}</span>
                  <div className="workflow-card__icon">{item.icon}</div>
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                  <ArrowUpRight className="workflow-card__arrow" size={18} />
                </motion.article>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      <section className="dashboard-tease section-pad">
        <div className="container dashboard-tease__grid">
          <Reveal>
            <SectionLabel index="04">{t("home.insideLabel")}</SectionLabel>
            <h2>{t("home.insideTitle1")}<br /><em>{t("home.insideTitleEm")}</em></h2>
            <p>{t("home.insideBody")}</p>
            <div className="feature-points">
              <div><ShieldCheck size={17} /><span>{t("home.feature1")}</span></div>
              <div><BarChart3 size={17} /><span>{t("home.feature2")}</span></div>
              <div><LockKeyhole size={17} /><span>{t("home.feature3")}</span></div>
            </div>
            <Link href="/dashboard" className="button button--outline">{t("home.explorePreview")} <ArrowUpRight size={16} /></Link>
          </Reveal>
          <Reveal delay={0.15} variants={{ hidden: { opacity: 0, scale: 0.94 }, show: { opacity: 1, scale: 1, transition: { duration: 0.7, ease: [0.23, 1, 0.32, 1] } } }}>
            <div className="dashboard-preview">
              <div className="dashboard-preview__art" aria-hidden="true">
                <motion.span className="artifact-ring artifact-ring--one" animate={{ rotate: [22, 26, 22] }} transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }} />
                <motion.span className="artifact-ring artifact-ring--two" animate={{ rotate: [22, 18, 22] }} transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }} />
                <span className="artifact-trace" /><span className="artifact-mark"><i /><i /><i /></span>
                <span className="artifact-label">TRACE / 08.42</span>
              </div>
              <div className="dashboard-preview__overlay">
                <div className="mini-window__top"><span>{t("home.liveViewDemo")}</span><span className="mini-status"><i /> {t("home.synced")}</span></div>
                <div className="mini-metric">
                  <span>{t("home.portfolioPosture")}</span><strong>{t("home.measured")}</strong>
                  <div className="mini-bars">{[0, 1, 2, 3, 4].map((i) => <motion.i key={i} initial={{ scaleY: 0 }} whileInView={{ scaleY: 1 }} viewport={{ once: true }} transition={{ delay: i * 0.08, duration: 0.5, ease: [0.23, 1, 0.32, 1] }} style={{ transformOrigin: "bottom" }} />)}</div>
                </div>
                <div className="mini-bottom"><span>BTC / USD</span><strong>+2.41%</strong></div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="boundary section-pad">
        <div className="container boundary__inner">
          <Reveal as={motion.div} className="boundary__icon" variants={fadeUp}><CircleAlert size={22} /></Reveal>
          <Reveal delay={0.1}><SectionLabel index="05">{t("home.boundaryLabel")}</SectionLabel><h2>{t("home.boundaryTitle")}</h2><p>{t("home.boundaryBody")}</p></Reveal>
          <Reveal delay={0.2} className="text-link">
            <button onClick={showSoon} className="text-link" style={{ background: "none" }}>{t("home.readRisk")} <ChevronRight size={15} /></button>
          </Reveal>
        </div>
      </section>

      <section className="closing-cta section-pad">
        <div className="container closing-cta__inner">
          <Reveal><span className="eyebrow">{t("home.closingEyebrow")}</span><h2>{t("home.closingTitle1")}<br /><em>{t("home.closingTitleEm")}</em></h2></Reveal>
          <Reveal delay={0.15} className="closing-cta__action">
            <p>{t("home.closingBody")}</p>
            <motion.div whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} style={{ display: "inline-block" }}>
              <Link href="/research" className="button button--copper">{t("home.enterJournal")} <Play size={15} /></Link>
            </motion.div>
          </Reveal>
        </div>
      </section>
    </SiteShell>
  );
}
