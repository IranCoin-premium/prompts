/*
 * Style direction: «سکوتِ کوانت» — research reads like a quiet field journal: editorial hierarchy,
 * evidence metadata, copper indexing, and no manufactured performance claims.
 */
import { ArrowUpRight, BookOpen, ChevronRight, Clock3, FileText, Filter, Search, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import { AnimatePresence } from "framer-motion";
import { EvidenceRail, SectionLabel, SiteShell } from "@/components/SiteShell";
import { motion, Reveal, Stagger, StaggerItem } from "@/components/Motion";
import { useLanguage } from "@/lib/i18n";

export default function Research() {
  const { t } = useLanguage();

  const articles = [
    { id: "01", categoryKey: "research.catStructure", titleKey: "research.a1title", summaryKey: "research.a1summary", date: "14 Aug 2026", read: "08", confKey: "research.confHigh", tone: "copper" },
    { id: "02", categoryKey: "research.catRisk", titleKey: "research.a2title", summaryKey: "research.a2summary", date: "09 Aug 2026", read: "11", confKey: "research.confReviewed", tone: "sage" },
    { id: "03", categoryKey: "research.catMacro", titleKey: "research.a3title", summaryKey: "research.a3summary", date: "31 Jul 2026", read: "06", confKey: "research.confMedium", tone: "blue" },
    { id: "04", categoryKey: "research.catProduct", titleKey: "research.a4title", summaryKey: "research.a4summary", date: "22 Jul 2026", read: "05", confKey: "research.confReviewed", tone: "sand" },
    { id: "05", categoryKey: "research.catExecution", titleKey: "research.a5title", summaryKey: "research.a5summary", date: "14 Jul 2026", read: "09", confKey: "research.confHigh", tone: "copper" },
  ];

  const categories = ["research.catAll", "research.catStructure", "research.catRisk", "research.catMacro", "research.catProduct", "research.catExecution"];
  const [activeCategory, setActiveCategory] = useState("research.catAll");
  const filtered = useMemo(
    () => (activeCategory === "research.catAll" ? articles : articles.filter((article) => article.categoryKey === activeCategory)),
    [activeCategory], // eslint-disable-line react-hooks/exhaustive-deps
  );
  const openSoon = () => toast(t("toast.readMore"), { description: t("toast.readMoreDesc") });

  return (
    <SiteShell>
      <section className="page-intro section-pad">
        <div className="container page-intro__grid">
          <Reveal>
            <EvidenceRail label={t("research.editorialDesk")} value={t("research.notesUpdated")} />
            <SectionLabel index="01">{t("research.journalLabel")}</SectionLabel>
            <h1>{t("research.contextFor1")}<br /><em>{t("research.contextForEm")}</em></h1>
          </Reveal>
          <Reveal delay={0.15} className="page-intro__aside">
            <p>{t("research.journalLede")}</p>
            <div className="page-intro__meta"><span><BookOpen size={15} /> {t("research.originalNotes")}</span><span><ShieldCheck size={15} /> {t("research.reviewedMethod")}</span></div>
          </Reveal>
        </div>
      </section>
      <section className="research-toolbar">
        <div className="container research-toolbar__inner">
          <div className="category-tabs" role="tablist" aria-label="Filter research">
            <Filter size={15} />
            {categories.map((category) => (
              <button key={category} onClick={() => setActiveCategory(category)} className={activeCategory === category ? "is-active" : ""} role="tab" aria-selected={activeCategory === category}>
                {t(category)}
              </button>
            ))}
          </div>
          <button className="search-button" onClick={openSoon}><Search size={16} /> {t("research.searchArchive")}</button>
        </div>
      </section>
      <section className="research-list section-pad">
        <div className="container">
          <div className="research-list__header"><span className="eyebrow">{t("research.showing")} {filtered.length.toString().padStart(2, "0")} {t("research.notes")}</span><span className="mono-label">{t("research.sortNewest")}</span></div>
          <AnimatePresence mode="popLayout">
            <Stagger className="article-stack">
              {filtered.map((article) => (
                <StaggerItem key={article.id} as={motion.article} className={`article-row article-row--${article.tone}`} onClick={openSoon}>
                  <div className="article-row__index">{article.id}</div>
                  <div className="article-row__visual">
                    <div className="article-row__visual-lines" />
                    <span className="article-row__visual-mark"><i /><i /><i /></span>
                    <span>{t(article.categoryKey)}</span>
                    <small>{t(article.confKey)} / {article.date}</small>
                  </div>
                  <div className="article-row__content">
                    <div className="article-row__category">{t(article.categoryKey)}<span>·</span>{t(article.confKey)}</div>
                    <h2>{t(article.titleKey)}</h2>
                    <p>{t(article.summaryKey)}</p>
                    <div className="article-row__meta"><span><Clock3 size={14} /> {article.read} {t("research.read")}</span><span>{article.date}</span></div>
                  </div>
                  <ArrowUpRight className="article-row__arrow" size={20} />
                </StaggerItem>
              ))}
            </Stagger>
          </AnimatePresence>
        </div>
      </section>
      <section className="methodology section-pad section-dark">
        <div className="container methodology__grid">
          <Reveal><SectionLabel index="02">{t("research.methodLabel")}</SectionLabel><h2>{t("research.signalsAre1")}<br /><span>{t("research.signalsAreEm")}</span></h2></Reveal>
          <Reveal delay={0.15} className="methodology__body">
            <p>{t("research.methodBody")}</p>
            <div className="methodology__steps">
              <div><b>01</b><span>{t("research.step1")}</span></div>
              <div><b>02</b><span>{t("research.step2")}</span></div>
              <div><b>03</b><span>{t("research.step3")}</span></div>
            </div>
            <Link href="/dashboard" className="text-link">{t("research.seeMethod")} <ChevronRight size={15} /></Link>
          </Reveal>
        </div>
      </section>
      <Reveal as={motion.section} className="research-subscribe section-pad">
        <div className="container research-subscribe__inner">
          <FileText size={22} />
          <div><span className="eyebrow">{t("research.weeklyFieldNote")}</span><h2>{t("research.oneConsideredRead1")}<br /><em>{t("research.oneConsideredReadEm")}</em></h2></div>
          <div className="subscribe-form">
            <input aria-label="Email address" placeholder={t("research.emailPlaceholder")} />
            <motion.button className="button button--copper" whileTap={{ scale: 0.97 }} onClick={() => toast(t("toast.subscribed"), { description: t("toast.subscribedDesc") })}>{t("research.requestAccess")} <ArrowUpRight size={16} /></motion.button>
          </div>
        </div>
      </Reveal>
    </SiteShell>
  );
}
