# IranCoin Premium — Final Frontend Package

این بسته شامل سورس کامل پروژهٔ فرانت‌اند تا آخرین نسخهٔ ثبت‌شده، سند مادر پرامپت‌ها و فهرست جامع کارهای استخراج‌شده از ۲۰ پارت است.

## محتویات اصلی

| مسیر | توضیح |
|---|---|
| `client/` | رابط کاربری React، صفحات، کامپوننت‌ها، استایل و تنظیمات HTML |
| `ideas.md` | جهت طراحی انتخاب‌شده و تصمیمات بصری پروژه |
| `todo.md` | فهرست وضعیت داخلی توسعه و تغییرات اخیر |
| `todo.list` | چک‌لیست جامع استخراج‌شده از تمام ۲۰ پارت پرامپت |
| `client/src/pages/TrustCenter.tsx` | Trust Center با capability matrix و وضعیت‌های توضیح‌دار |
| `client/src/pages/Operations.tsx` | UI صفحات Positions، Alerts، Automations و Settings |
| `client/src/contexts/LanguageContext.tsx` | سوییچ پایدار فارسی/انگلیسی با RTL/LTR |
| `client/src/pages/Settings.tsx` | تنظیمات ظاهری و شخصی‌سازی frontend-only |
| `client/src/pages/Profile.tsx` | مرکز مدیریت حساب، امنیت و ترجیحات frontend-only |
| `client/src/pages/Transactions.tsx` | تاریخچهٔ تراکنش‌ها و فیلترهای پیشرفته frontend-only |
| `client/src/pages/Support.tsx` | مرکز پشتیبانی، FAQ و تیکتینگ frontend-only |
| `client/src/pages/Wallet.tsx` | کیف پول، نمودار دارایی و flowهای Send/Receive frontend-only |
| `client/src/pages/KYC.tsx` | فرایند احراز هویت و آپلود مدارک frontend-only |
| `client/src/pages/PortfolioAnalytics.tsx` | گزارش‌گیری پرتفوی و نمودارهای تعاملی frontend-only |
| `client/src/pages/Notifications.tsx` | مرکز اعلان‌ها و پیام‌های صرافی frontend-only |
| `all_prompts.md` | سند اصلی و کامل پرامپت‌های دریافتی |
| `package.json` | وابستگی‌ها و اسکریپت‌های پروژه |
| `server/` و `shared/` | فایل‌های سازگاری اسکفولد اولیه |

## اجرای محلی

در ریشهٔ پروژه، ابتدا وابستگی‌ها را نصب کنید و سپس سرور توسعه را اجرا کنید:

```bash
pnpm install
pnpm dev
```

برای کنترل نهایی نیز می‌توانید از این فرمان‌ها استفاده کنید:

```bash
pnpm check
pnpm build
```

> این نسخهٔ فرانت‌اند است. داده‌های بازار، ذخیره‌سازی پروفایل، احراز هویت، پرداخت، اتصال venue و اجرای واقعی معامله هنوز به سرویس‌های بک‌اند و بررسی‌های حقوقی/امنیتی نیاز دارند.

## تغییرات این فاز — 28 Aug 2026

صفحهٔ `/trust-center` اضافه شد تا تفاوت بین آموزش عمومی، اطلاعات بازار، preview سیگنال، قابلیت‌های gated و محصولات off را شفاف کند. این صفحه همچنین اصل safe default، نگهداری secret خارج از UI و نیاز به بررسی jurisdiction، entitlement، eligibility و technical readiness را توضیح می‌دهد. این تغییر صرفاً UX و مستندسازی فرانت‌اند است و هیچ اتصال واقعی، احراز هویت، مجوز فعالیت یا قابلیت ثبت سفارش ایجاد نمی‌کند.

در فاز بعدی، مسیرهای `/positions`، `/alerts`، `/automations` و `/settings` با stateهای نمایشی و navigation مستقل اضافه شدند. سوییچ زبان در header قرار گرفته و انتخاب کاربر را در local storage نگه می‌دارد؛ حالت فارسی، `lang="fa"` و `dir="rtl"` را روی سند اعمال می‌کند. این قابلیت نیز کاملاً frontend-only است.

صفحهٔ Settings در این فاز به چهار پنل Appearance، Workspace، Accessibility و Local data گسترش یافت و تم روشن/تیره، رنگ تأکیدی، تراکم رابط، نمودار فشرده، focus mode، صدای رابط و بازنشانی تنظیمات محلی را ارائه می‌کند. این گزینه‌ها فقط رفتار ظاهری همین مرورگر را تغییر می‌دهند و به بک‌اند متصل نیستند.

صفحهٔ Profile نیز به پنج بخش Overview، Account details، Notifications، Security و Preferences ارتقا یافت. وضعیت تکمیل پروفایل، وضعیت ایمیل، سطح دسترسی، نشست‌های فعال، 2FA، دستگاه‌ها، تغییر avatar، اعلان‌ها و وضعیت export داده در سطح UI نمایش داده می‌شوند؛ اجرای واقعی این عملیات همچنان به authentication، session service و backend امن نیاز دارد.

صفحهٔ `/transactions` نیز اضافه شد و شامل جدول تاریخچهٔ نمونه، حجم نمایش‌داده‌شده، تعداد رکوردهای تکمیل‌شده و در انتظار، جست‌وجوی آزاد، فیلتر بازه، نوع تراکنش، وضعیت، دارایی، مرتب‌سازی و پاک‌کردن فیلترهاست. داده‌ها عمداً illustrative هستند و export واقعی، pagination و جزئیات رکورد نیازمند backend باقی می‌مانند.

صفحهٔ `/support` یک مرکز پشتیبانی دوزبانه با FAQ، جست‌وجوی تیکت، فیلتر وضعیت، لیست مکالمه‌ها و modal ساخت تیکت دارد. ساخت تیکت در این نسخه فقط یک draft محلی و frontend-only است؛ ارسال واقعی، inbox، SLA، attachment و پاسخ اپراتور به سرویس backend نیاز دارند.

صفحهٔ `/wallet` به‌عنوان رابط کیف پول اضافه شد و شامل نمودار ارزش کل، تخصیص دارایی، جدول balances، فعالیت اخیر و تب‌های Send و Receive است. آدرس، QR، کارمزد و موجودی‌ها عمداً نمونه هستند؛ ارسال/دریافت واقعی، address validation، network confirmation، transaction signing و wallet custody خارج از این نسخه و نیازمند سرویس امن backend هستند.

صفحهٔ `/kyc` یک flow چهارمرحله‌ای برای اطلاعات هویتی، آپلود مدارک، مرور و تکمیل ایجاد می‌کند. upload box، preview فایل، حذف فایل، validation، consent و حالت تکمیل در سطح UI وجود دارند؛ فایل‌ها در این نسخه ارسال یا ذخیره نمی‌شوند و برای محصول واقعی به encryption، access control، retention policy و سرویس امن احراز هویت نیاز است.

صفحهٔ `/portfolio-analytics` گزارش‌های نمایشی ارزش پرتفوی، تخصیص دارایی، عملکرد، ریسک و drawdown را با نمودارهای Recharts ارائه می‌کند. انتخاب بازه، فیلتر asset، tooltip، benchmark و metric toggle تعاملی هستند؛ داده‌های زنده، محاسبهٔ واقعی، benchmark قابل تنظیم و export گزارش همچنان نیازمند backend هستند.

صفحهٔ `/notifications` صندوق ورودی دوزبانه برای اعلان‌ها و پیام‌های صرافی فراهم می‌کند؛ شامل دسته‌بندی امنیت، بازار، محصول و حساب، فیلتر priority، جست‌وجو، خوانده/خوانده‌نشده، starred، mark all read و modal جزئیات است. این پیام‌ها نمونه هستند و inbox صرافی یا اعلان زنده متصل نیست.

**آخرین نسخهٔ پروژه:** checkpoint `292df07a`؛ بستهٔ ZIP حاضر شامل تغییرات پس از آن، از جمله todo.list جامع است.
