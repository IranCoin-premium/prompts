import { createContext, useContext, useEffect, useState } from "react";

export type Language = "en" | "fa";
const LanguageContext = createContext<{ language: Language; toggleLanguage: () => void; isPersian: boolean } | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem("irancoin-language") as Language) || "en");
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "fa" ? "rtl" : "ltr";
    localStorage.setItem("irancoin-language", language);
  }, [language]);
  return <LanguageContext.Provider value={{ language, isPersian: language === "fa", toggleLanguage: () => setLanguage((current) => current === "en" ? "fa" : "en") }}>{children}</LanguageContext.Provider>;
}
export function useLanguage() { const context = useContext(LanguageContext); if (!context) throw new Error("useLanguage must be used within LanguageProvider"); return context; }
