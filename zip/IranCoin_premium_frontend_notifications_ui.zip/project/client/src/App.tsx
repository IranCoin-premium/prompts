/*
 * Style direction: «سکوتِ کوانت» — dark editorial finance, asymmetric layouts, copper signal accents,
 * calm motion, and explicit product boundaries. Keep the shell quiet so evidence and actions lead.
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import Home from "./pages/Home";
import Research from "./pages/Research";
import Dashboard from "./pages/Dashboard";
import Pricing from "./pages/Pricing";
import Profile from "./pages/Profile";
import TrustCenter from "./pages/TrustCenter";
import NotFound from "./pages/NotFound";
import Operations from "./pages/Operations";
import Settings from "./pages/Settings";
import Transactions from "./pages/Transactions";
import Support from "./pages/Support";
import Wallet from "./pages/Wallet";
import KYC from "./pages/KYC";
import PortfolioAnalytics from "./pages/PortfolioAnalytics";
import Notifications from "./pages/Notifications";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/research" component={Research} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/positions" component={Operations} />
      <Route path="/alerts" component={Operations} />
      <Route path="/automations" component={Operations} />
      <Route path="/settings" component={Settings} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/support" component={Support} />
      <Route path="/wallet" component={Wallet} />
      <Route path="/kyc" component={KYC} />
      <Route path="/portfolio-analytics" component={PortfolioAnalytics} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/profile" component={Profile} />
      <Route path="/trust-center" component={TrustCenter} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <LanguageProvider>
          <TooltipProvider>
            <Toaster position="bottom-left" richColors />
            <Router />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
