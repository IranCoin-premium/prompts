import { ArrowUpRight, Check, CircleHelp, Globe2, LockKeyhole, ShieldCheck, X } from "lucide-react";
import { Link } from "wouter";
import { SiteShell, SectionLabel } from "@/components/SiteShell";
import { toast } from "sonner";

const capabilities = [
  { name: "Research journal", className: "Public education", web: "Available", mobile: "Available", note: "Editorial context with source and update metadata." },
  { name: "Signal watchlist", className: "Market information", web: "Preview", mobile: "Preview", note: "Illustrative context only; not an instruction or guarantee." },
  { name: "Venue connection", className: "Automated execution", web: "Gated", mobile: "Gated", note: "Requires jurisdiction, eligibility, entitlement and technical checks." },
  { name: "Binary-options related flows", className: "Restricted product", web: "Off", mobile: "Off", note: "Not offered in this preview; distribution and legal review are required." },
];

function Status({ value }: { value: string }) {
  const off = value === "Off";
  const gated = value === "Gated";
  return <span className={`trust-status ${off ? "trust-status--off" : gated ? "trust-status--gated" : ""}`}>{off ? <X size={12} /> : gated ? <LockKeyhole size={12} /> : <Check size={12} />}{value}</span>;
}

export default function TrustCenter() {
  const soon = () => toast("این قابلیت هنوز به سرویس امن سمت سرور متصل نیست.", { description: "این صفحه وضعیت فعلی رابط و مرزهای محصول را شفاف می‌کند؛ مجوز یا تأییدیهٔ حقوقی محسوب نمی‌شود." });
  return <SiteShell><div className="trust-page"><header className="trust-hero"><div><span className="eyebrow">IranCoin / Trust center</span><h1>Clarity before<br /><em>capability.</em></h1><p>یک نمای شفاف از اینکه هر قابلیت در این پیش‌نمایش چه وضعیتی دارد، چه چیزی هنوز ناشناخته است و قبل از فعال‌سازی چه بررسی‌هایی لازم است.</p><div className="trust-actions"><Link className="button button--copper" href="/dashboard">Open workspace <ArrowUpRight size={15} /></Link><button className="button button--outline" onClick={soon}>Review operating model <CircleHelp size={15} /></button></div></div><div className="trust-seal"><ShieldCheck size={28} /><span>SAFE DEFAULTS</span><strong>No live orders</strong><small>Preview boundary · 28 Aug 2026</small></div></header><section className="trust-section"><SectionLabel index="01">Capability matrix</SectionLabel><div className="trust-table" role="table" aria-label="Capability availability matrix"><div className="trust-table__head" role="row"><span>Capability</span><span>Web / PWA</span><span>Client apps</span><span>Why this state</span></div>{capabilities.map((item) => <div className="trust-table__row" role="row" key={item.name}><div><strong>{item.name}</strong><small>{item.className}</small></div><Status value={item.web} /><Status value={item.mobile} /><p>{item.note}</p></div>)}</div></section><section className="trust-grid"><article className="trust-card"><Globe2 size={18} /><span className="eyebrow">Gating dimensions</span><h2>Context changes access.</h2><p>فعال‌سازی واقعی باید بر اساس پلتفرم، کشور، وضعیت مجوز، احراز هویت، سن، بازار، venue، پرداخت، اشتراک و آمادگی فنی تصمیم‌گیری شود.</p><button className="text-link" onClick={soon}>See required checks <ArrowUpRight size={14} /></button></article><article className="trust-card"><LockKeyhole size={18} /><span className="eyebrow">Credential boundary</span><h2>Secrets stay out of the UI.</h2><p>کلیدها و secretهای venue در این فرانت‌اند ذخیره یا نمایش داده نمی‌شوند. مدل هدف: انتقال TLS، رمزنگاری سمت سرور، حداقل دسترسی، برداشت خاموش و قابلیت لغو.</p><button className="text-link" onClick={soon}>View security principles <ArrowUpRight size={14} /></button></article></section><section className="trust-foot"><span className="eyebrow">Evidence note</span><p>این مرکز اعتماد، وضعیت محصول را مستند می‌کند و جایگزین بررسی حقوقی، مجوز فعالیت، مشاوره سرمایه‌گذاری یا تضمین پذیرش فروشگاه نیست.</p><Link href="/research" className="text-link">Read the research journal <ArrowUpRight size={14} /></Link></section></div></SiteShell>;
}
